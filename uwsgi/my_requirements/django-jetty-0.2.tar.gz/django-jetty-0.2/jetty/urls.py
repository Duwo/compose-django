from django.conf.urls import patterns, include, url
from django.views.generic import TemplateView
from jetty import views

urlpatterns = [
	url(r'^$', views.IndexView.as_view(title ='About Me'), name='index'),
    url(r'^photologue/gallerylist/$', views.GalleryListView.as_view(), name='gallery-list'),
	url(r'^photologue/gallery/(?P<slug>[\-\d\w]+)/$',
						   views.GalleryDetailView.as_view(), name='pl-gallery'),
]