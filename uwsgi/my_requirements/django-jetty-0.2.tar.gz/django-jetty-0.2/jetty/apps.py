from django.apps import AppConfig


class JettyConfig(AppConfig):
    name = 'jetty'