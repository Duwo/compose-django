from django.shortcuts import render
from django.views.generic import TemplateView
from django.views.generic import ListView
from photologue.views import GalleryListView
from photologue.views import GalleryDetailView
from photologue.models import Gallery
# Create your views here.

class TitleView(TemplateView):
    title = None
    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, {"title" : self.title})

class IndexView(TitleView):
    template_name ='jetty/index.html'
    
#print Gallery.objects.on_site().is_public()    
class GalleryListView(GalleryListView):
    template_name ='jetty/gallerylist.html'
    # print object_list.filter(title="induwo_gallery") 
    queryset = Gallery.objects.on_site().is_public()
    #paginate_by = 20

class GalleryDetailView(GalleryDetailView):
    #queryset = Gallery.objects.is_public()
    template_name ='jetty/detail_portfolio.html'
    
