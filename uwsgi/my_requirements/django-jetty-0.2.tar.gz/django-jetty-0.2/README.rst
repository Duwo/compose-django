=====
Induwo
=====

Polls is a simple Django app to conduct Web-based polls. For each
question, visitors can choose between a fixed number of answers.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "jetty" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'jetty',
        ...
        'photologue',
    ]

   before photologue to match the templates in correct order

2. Include the polls URLconf in your project urls.py like this::

   url(r'^jetty/', include('polls.urls')),

3. Run `python manage.py migrate` to create the models.
