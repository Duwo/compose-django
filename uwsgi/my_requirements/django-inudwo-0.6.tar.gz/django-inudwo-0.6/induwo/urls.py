from django.conf.urls import url
from django.conf.urls import patterns, url
from induwo import views
from django.views.generic import TemplateView

app_name = 'induwo'
urlpatterns = [
  url(r'^$', views.IndexView.as_view(title ='About Me'), name='index'),
  url(r'^animations/$', views.AnimationsView.as_view(title ='Animations'), name='animations'),
  url(r'^links/$', views.LinksView.as_view(title ='Links'), name='links'),
  url(r'^games/$', views.GamesView.as_view(title ='Javascript Games'), name='games'),
  url(r'^contact/$', views.ContactView.as_view(title ='Contact'), name='contact'),
  url(r'^collage/$', views.CollageView.as_view(title ='Collage'), name='collage'),
  url(r'^events/$', views.EventsView.as_view(title ='Events'), name='events'),
  url(r'^curriculum_vitae/$', views.CvView.as_view(title ='Curriculum Vitae'), name='cv'),
  url(r'^pictures/$',views.PicturesView.as_view(title ='Pictures'), {'slug': 'induwo_gallery'}, name='pl-gallery'),
]
      
