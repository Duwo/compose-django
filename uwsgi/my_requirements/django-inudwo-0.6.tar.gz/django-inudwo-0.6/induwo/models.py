from django.db import models
import datetime
from django.utils import timezone
from eventtools.models import BaseEvent, BaseOccurrence

# Create your models here.

class Event(BaseEvent):
    title = models.CharField(max_length=100)

class Occurrence(BaseOccurrence):
    event = models.ForeignKey(Event)

## @brief Writing The writing objects presented
class Writing(models.Model):
  writing_text = models.TextField()
  writing_date = models.DateTimeField('writing date')

  def __str__(self):
    return self.writing_text

class WritingComment(models.Model):
    text = models.CharField(max_length=100)
    post = models.ForeignKey(Writing)

class Link(models.Model):
  link_path = models.CharField(max_length=100)
  link_name = models.CharField(max_length=100)
  link_type = models.CharField(max_length=2, default=None)
    






