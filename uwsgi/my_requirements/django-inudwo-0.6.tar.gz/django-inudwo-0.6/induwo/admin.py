from django.contrib import admin

# Register your models here.
from induwo.models import Writing, Link, Event, Occurrence
from induwo.forms import LinksForm
# Youll follow this pattern  create a model admin object, then pass it as the second argument to admin.site.register any time you need to change the admin options for an object.

class BlogPostAdmin(admin.ModelAdmin):
    fieldsets = [
        (None,               {'fields': ['blogpost_text']}),
        ('Date information', {'fields': ['blogpost_date']}),
    ]
    list_display = ('blogpost_text', 'blogpost_date')
    list_filter = ['blogpost_date']
    search_fields = ['blogpost_text']

class WritingAdmin(admin.ModelAdmin):
    fieldsets = [
        (None,               {'fields': ['writing_text']}),
        ('Date information', {'fields': ['writing_date']}),
    ]
    list_display = ('writing_text', 'writing_date')
    list_filter = ['writing_date']
    search_fields = ['writing_text']

class LinkAdmin(admin.ModelAdmin):
    form = LinksForm

class EventAdmin(admin.ModelAdmin):
    fieldsets = [
        ('Title',    {'fields': ['title']})
    ]
    list_display = ['title']
    search_fields = ['title']

class EventAdmin(admin.ModelAdmin):
    fieldsets = [
        ('Title',    {'fields': ['title']})
    ]
    list_display = ['title']
    search_fields = ['title']
    
admin.site.register(Link, LinkAdmin)
admin.site.register(Writing, WritingAdmin)
admin.site.register(Event, EventAdmin)
admin.site.register(Occurrence)
