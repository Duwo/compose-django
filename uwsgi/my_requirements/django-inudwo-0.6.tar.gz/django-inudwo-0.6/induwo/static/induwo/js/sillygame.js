function movebutton() {
  var section = $( "#sillywindow" );
  var myBtn = $("#myBtn");
  var spacex = Math.round(section.width() - myBtn.width() * 2);
  var spacey = Math.round(section.height() - myBtn.height() * 2);
  var left_margin  = Math.round(section.position().left);
  var top_margin  = Math.round(section.position().top);
  var xpos = Math.round(Math.random() * spacex + left_margin);
  var ypos = Math.round(Math.random() * spacey + top_margin);
  myBtn.offset({top: ypos, left: xpos});
};