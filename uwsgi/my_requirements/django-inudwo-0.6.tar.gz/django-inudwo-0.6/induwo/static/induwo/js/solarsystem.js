var scene1, camera1, renderer1;
var scene2, camera2, renderer2;
animation1 = document.getElementById( 'animation1' );
renderer1 = new THREE.WebGLRenderer();
renderer1.domElement.id = 'canvas';
renderer1.setSize(animation1.clientWidth, animation1.clientWidth)
animation1.appendChild( renderer1.domElement );

init();

var t = 0;
var phi = 0;
var theta = 0;
var camera_radius = 50;
var dtheta = 0;
var i = 0;
animate();
    
var Planet = function() {
  this.mesh = mesh
  this.position_x = position[x]
  this.position_y = position[x]
  this.position_z = position[x]
};

Planet.prototype.create_from_params = function(geometry,   planets) {
  this.mesh
};

var Solarsystem = function(planets) {
  this.planets = planets
};
  
Solarsystem.prototype.addPlanets = function(scene, planets) {
  for (i = 0; i < this.planets.length; i++) { 
    scene.add(planets[i])
  };
};

function init() {
  scene = new THREE.Scene();        
  camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 1, 100 );
  /* Start of camera view coordinates */
  camera.position.x = 0;
  camera.position.y = 40;
  camera.position.z = 0;
  sun_geometry = new THREE.SphereGeometry( 4, 32, 32 );
  sun_material = new THREE.MeshBasicMaterial({ color: 0xffff00, wireframe: false }) 
  sun = new THREE.Mesh(sun_geometry, sun_material);          
  earth_geometry = new THREE.SphereGeometry( 1, 32, 32 );
  earth_material = new THREE.MeshBasicMaterial( { color: 0xaf1f26, wireframe: false } );              
  earth = new THREE.Mesh( earth_geometry, earth_material );       
  earth.translateX(-12.5)     
  mars_geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  mars_material = new THREE.MeshBasicMaterial( { color: 0xaf1f26, wireframe: false } );               
  mars = new THREE.Mesh( mars_geometry, mars_material );      
  mars.translateX(-25)        
  lines = new THREE.Geometry();
  lines.vertices.push(
    new THREE.Vector3( -20, -20, 0 ),
    new THREE.Vector3( 20, -20, 0 ),
    new THREE.Vector3( 20, 20, 0 ),
    new THREE.Vector3( -20, 20, 0 ),
    new THREE.Vector3( -20, -20, 0 )
  );
  line_material = new THREE.LineBasicMaterial({
    color: 0x00ffff
  });     
  lines2 = new THREE.Geometry();
  lines2.vertices.push(
    new THREE.Vector3( 0, -20, -20 ),
    new THREE.Vector3( 0, -20, 20 ),
    new THREE.Vector3( 0, 20, 20 ),
    new THREE.Vector3( 0, 20, -20 ),
    new THREE.Vector3( 0, -20, -20 )
  );    
  lines3 = new THREE.Geometry();
  lines3.vertices.push(
    new THREE.Vector3(-20, 0, -20 ),
    new THREE.Vector3(-20, 0, 20 ),
    new THREE.Vector3(20, 0, 20 ),
    new THREE.Vector3(20, 0, -20 ),
    new THREE.Vector3(-20, 0, -20 )
  );
  var frame = new THREE.Line( lines, line_material );
  var frame2 = new THREE.Line( lines2, line_material );
  var frame3 = new THREE.Line( lines3, line_material );
  scene.add( sun );
  scene.add( earth );
  scene.add( mars );
  scene.add( frame );
  scene.add( frame2 );
  scene.add( frame3 );
  camera.lookAt(new THREE.Vector3( 0, 0, 0));
  renderer1.domElement.addEventListener( 'click', function () {
    if ( this.requestFullscreen ) {
      this.requestFullscreen();
    } else if ( this.msRequestFullscreen ) {
      this.msRequestFullscreen();
    } else if ( this.mozRequestFullScreen ) {
      this.mozRequestFullScreen();
    } else if ( this.webkitRequestFullscreen ) {
      this.webkitRequestFullscreen();
    }
  });      
}
function animate() {
  requestAnimationFrame( animate );
  deltat = 0.08 
  t += deltat     
  /* mesh.rotation.x += 0.001; */    
  dphi = 0.01
  phi += dphi
  theta = Math.cos(phi)
  camera.position.x = camera_radius * Math.sin(phi) * Math.cos(theta)
  camera.position.y = camera_radius * Math.sin(phi) * Math.sin(theta)
  camera.position.z = camera_radius * Math.cos(phi)         
  camera.lookAt(new THREE.Vector3( 0, 0, 0))    
  earth.translateX(Math.sin(t))
  earth.translateZ(Math.cos(t))
  mars.translateX(deltat*0.5*25*Math.sin(0.5*t))
  mars.translateZ(deltat*0.5*25*Math.cos(0.5*t))
  renderer1.render( scene, camera );
  renderer1.setSize(animation1.clientWidth, animation1.clientWidth)
}