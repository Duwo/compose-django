//Lost memories, lost memories, how fast do the winds of change blow across the sands of time? How rough is the storm you must weather?

var blowing_shifting_speed_of_change = 10;

//Slipping, sliding, sloping sand, how we change our values. How far from home are you willing to go? How far will you follow that shimmering mirage?

var distance_I_will_stumble_through_this_place = 10;

//A background, a past that sometimes rears its head when we try to change ourselves. It doesn't really matter.
background(0, 0, 0);

//And yet...
var chaos_and_confusion = 10;

//Lost memories threaten to overwhelm. If it grows to be too much for you, do not dwell. On the next line type "Shhhhh..."


//Ah, yes, a reminder that this is life, this is real live code, there is nothing hidden here, nothing secret. If I am to break, it is you who will have broken me. And you who can fix me.

var I_ruin_everything_I_touch = 10;

if (I_ruin_everything_I_touch !== 10) {[]();}//it's not you it's me

//Starting points, choices that don't matter in the end, yet must be made, just to have something to hold on to.
var changing_thing = 1;
var changing_thing2 = 1;
var direction = 1;
var direction2 = 1;

//now let us venture down, down into the draw loop...

var draw = function() {

//here, on the other side of that fateful bracket, doomed to run and repeat for as long as I am able, here where these words, safe beside slashing lines, are ignored not once but always.

// Tell me, tell me the color of your heart and soul and mind, as they sit in that dark memory:

var love_that_was_in_my_heart = 18; 
var life_that_was_in_my_soul = -221; 
var light_that_was_in_my_mind = 1;

// Show me, show me how you have changed:

var love_in_my_heart = 260; 
var life_in_my_soul = 85; 
var light_in_my_mind = 2;

// Ah, how you function. Let it be.
var and_round = function(Speed, Radius) {
    return { speed: Speed, radius: Radius };
};

//this is how it will work when we call each frame of recollection:
var Circles_of_circles = function( startX, startY, how_we_go_round, prism_of_recollection, lost_memories ) 
{
    //innocent beginnings.
    var angle = 0;
    var pastPos;
    
    //where will this path take us?
    for (var j = 0; j <= lost_memories/prism_of_recollection; ++j) 
    {
        //Here we are...
        var pos = {x: startX, y: startY};
        //If you have no past, the present must do.
        if ( !pastPos ) { pastPos = pos; }
    
        //Do you know circles? Would you dare change them?
        for (var i = 0; i < how_we_go_round.length; ++i) 
        {
            var angleS = angle * how_we_go_round[i].speed;
            pos.x += cos(angleS) * how_we_go_round[i].radius;
            pos.y += sin(angleS) * how_we_go_round[i].radius;
        }
        
        //how far, how far...
        var t = angle /360;
        
        //...let us put together the story of your three-part self.        
        stroke( love_that_was_in_my_heart * t + (1-t)*love_in_my_heart, life_that_was_in_my_soul * t + (1-t)*life_in_my_soul, light_that_was_in_my_mind * t + (1-t)*light_in_my_mind);
        
        //This is where we draw the line. This is the line we will keep coming back to:

        line(pastPos.x, pastPos.y, pos.x, pos.y);
        
        //It didn't have to be this way, with harsh unyielding "line". You could have lived in the shifting cities of "rect" or chased the dragon "ellipse." You could have made a "point" and forgotten your pasts. 

        //But if you do these things, forget the lines you've drawn, you might find yourself wanting more. Background. Weight. How will you ever get your fill?
        
        fill(255, 255, 255);

        //Let us rise, rise, make an incremental escape from this infernal for loop.
        angle += prism_of_recollection;
        pastPos = pos;
    }
    //Freedom beckons...
};

// Ah, and now the real prize. These are the circles that go round and compound, creating the lost landscape you've given me. Change these numbers, low and high, whole numbers, fractions, whatever you wish, I am yours.

var how_we_go_round = [ 
    and_round(-82,-230),
    and_round(84, changing_thing),
    and_round(changing_thing2,-46)
]; 

// Yet the memory of perfect circles is an illusion; perfection is broken by the faceted planes of reality...

var prism_of_recollection = 0.2; 

// yes, our perception is often murky and incomplete....

var lost_memories = 360; 

//Let us call forth those circles of life. Yes, it knows of life, but if we do not call its name it cannot live:
Circles_of_circles( 200, 200, how_we_go_round, prism_of_recollection, lost_memories );

//And where is the next link in our chain of memories? Let us keep it within the sight of mind. Let us hold our memories close, gathering them together if they wander too far...

if (changing_thing > 0) {direction = -1;}

//releasing them when they crowd our minds too tightly...

if (changing_thing < -214) {direction = 1;}

//Let us follow these links whichever way they must go, given breath by those winds...

changing_thing += direction * abs(blowing_shifting_speed_of_change/5);

//No matter how far...

if (changing_thing2 > distance_I_will_stumble_through_this_place/2) {direction2 = -1;}

//and in the end, let us journey back home.

if (changing_thing2 < 0) {direction2 = 1;}

//Now I must change and grow, using my chaos as my strength, and do it all again...

changing_thing2 += direction2 * abs(chaos_and_confusion/1000);

}; //end







