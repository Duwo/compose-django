
// 2. This code loads the IFrame Player API code asynchronously.
var tag = document.createElement('script');

tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
console.log(firstScriptTag);
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// 3. This function creates an <iframe> (and YouTube player)
//    after the API code downloads.
var player1;
var player2;
var player3;
function onYouTubeIframeAPIReady() {
  player1 = new YT.Player('player1', {
    start: '21',
    videoId: 'lytxafTXg6c',
    events: {
      'onReady': onPlayerReady,
    }

  });
  player2 = new YT.Player('player2', {
    videoId: 'obCjODeoLVw',
    events: {
      'onReady': onPlayerReady,
    }

  });
  player3 = new YT.Player('player3', {
    videoId: 'obCjODeoLVw',
    events: {
      'onReady': onPlayerReady,
    }
  });
}

// 4. The API will call this function when the video player is ready.
function onPlayerReady(event) {
  event.target.playVideo();
  if (event.target.o.id === "player1") {
      var start = 21;
      var milliseconds = 5000; 
      
      console.log("1sssddd")
      event.target.seekTo(start);
      setTimeout(replay(start, milliseconds), milliseconds);
  }
  if (event.target.o.id === "player2") {
      event.target.seekTo(454);
  }
}

// 5. The API calls this function when the player's state changes.
//    The function indicates that when playing a video (state=1),
//    the player should play for six seconds and then stop.
var counter1 = 0;
function replay(start, millisecnods) {
  
  console.log("1sssddd")
  if(counter1 < 3) {
    console.log(start)
    player1.seekTo(start);
    setTimeout(replay(start,millisecnods), 5000)
    counter1 += 1;
  }
}