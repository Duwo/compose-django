import datetime

from django.utils import timezone
from django.test import TestCase


from django.core.urlresolvers import reverse
from polls.models import Question
# Create your tests here.

## @brief Tests of my different views
class IndexViewTest(TestCase):
  def test_index_view(self):
    response = self.client.get(reverse('induwo:index'))
    self.assertEqual(response.status_code, 200)
    response = self.client.get('/induwo/')
    self.assertEqual(response.status_code, 200)


class PicturesViewTest(TestCase):
  def test_pictures_view(self):
    response = self.client.get(reverse('induwo:pl-gallery'))
    self.assertEqual(response.status_code, 200)
    response = self.client.get('/induwo/pictures/')
    self.assertEqual(response.status_code, 200)

class AnimationsViewTest(TestCase):
  def test_animations_view(self):
    response = self.client.get(reverse('induwo:animations'))
    self.assertEqual(response.status_code, 200)
    response = self.client.get('/induwo/animations/')
    self.assertEqual(response.status_code, 200)

class LinksViewTest(TestCase):
  def test_links_view(self):
    response = self.client.get(reverse('induwo:links'))
    self.assertEqual(response.status_code, 200)
    response = self.client.get('/induwo/links/')
    self.assertEqual(response.status_code, 200)
