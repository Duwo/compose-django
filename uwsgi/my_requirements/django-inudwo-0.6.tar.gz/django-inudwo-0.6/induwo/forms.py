## NOT SURE ABOUT THIS ONE!!!
from django import forms
class LinksForm(forms.ModelForm):
  fieldsets = [
        ('Link path',    {'fields': ['link_path']}),
        ('Link name',    {'fields': ['link_name']}),
        ('Link Type',    {'fields': ['link_type']})
  ]
  COMIC = 'CO'
  YOUTUBE = 'YT'
  OTHER = 'OT'
  LINK_TYPE_CHOICES = (
      (COMIC, 'Comic'),
      (YOUTUBE, 'Youtube'),
      (OTHER, 'Other'),
  )
  link_type = forms.ChoiceField(choices=LINK_TYPE_CHOICES)
  list_display = ('link_name', 'link_path')
  search_fields = ['Link name']

