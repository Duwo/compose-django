from django.shortcuts import get_object_or_404, render, render_to_response
from django.http import HttpResponseRedirect, HttpResponse
from django.core.urlresolvers import reverse
from django.utils import timezone
from django.core.paginator import (
    Paginator,
    EmptyPage,
    PageNotAnInteger,
)
from django.conf import settings
from django.http import Http404
from django.contrib import messages
from registration.views import  RegistrationView
from django.contrib.auth.views import login
from django.views.generic import TemplateView, ListView, DetailView

from induwo.models import Writing, Link
from photologue.views import GalleryDetailView

class TitleView(TemplateView):
  title = None
  def get(self, request, *args, **kwargs):
    return render(request, self.template_name, {"title" : self.title})

## @brief The start page of the websight
#  @praram[in] generic template
class IndexView(TitleView):
  template_name ='induwo/index.html'

## @brief A view of my Drawings 
#  @praram[in] generic template
class PicturesView(GalleryDetailView, TitleView):
  template_name ='induwo/pictures.html'

class AnimationsView(TitleView):
  template_name ='induwo/animations.html'

class LinksView(ListView, TitleView):
  model = Link
  template_name ='induwo/links.html'
  context_object_name = 'link_list'
  def get_queryset(self):
    return Link.objects.all()

class GamesView(TitleView):
  template_name ='induwo/games.html'

class ContactView(TitleView):
  template_name ='induwo/contact.html'

class CollageView(TitleView):
  template_name ='induwo/collage.html'

class CvView(TitleView):
  template_name ='induwo/cv.html'

class EventsView(TitleView):
  template_name ='induwo/events.html'