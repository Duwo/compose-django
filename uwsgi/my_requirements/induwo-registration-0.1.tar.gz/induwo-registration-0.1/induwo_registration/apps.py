from django.apps import AppConfig


class InduwoRegistrationConfig(AppConfig):
    name = 'induwo_registration'
